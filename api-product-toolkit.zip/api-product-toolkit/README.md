# API Product Toolkit

Three skills for product managers building public, partner, or internal APIs - based on
frameworks from *API Analytics for Product Managers* (Deepa Goyal).

Each skill is a plain folder with a `SKILL.md` file: a markdown document with a short
metadata header (name + description) and step-by-step instructions for producing a real
artifact, not just advice. This is a simple, tool-agnostic format - a `SKILL.md` is just
a well-structured prompt, so it works with any AI coding/agent tool that can read a file
and follow instructions, not only Claude.

## What's inside

| Skill | What it produces |
|---|---|
| `skills/api-prfaq-builder` | A PRFAQ (Press Release + FAQ) proposal document - the "should we build this" artifact, before any spec exists. |
| `skills/api-spec-builder` | A real OpenAPI 3.0 spec (YAML) from a plain-language API description - resources, auth, pagination, rate limiting, versioning. |
| `skills/api-metrics-kit` | Deployable monitoring config (Datadog Monitor JSON or PrometheusRule YAML) and a product-analytics tracking plan (JSON, for Amplitude/Mixpanel). |

Each skill is meant to be usable on its own, but they're designed to hand off to one
another across an API's lifecycle: PRFAQ (should we build it) → Spec (what does it look
like) → Metrics Kit (how do we know it's working).

## How to use

There's no single install command here - how you load a `SKILL.md` depends on the tool
you're using:

- **Point your AI tool at the folder or file directly.** Most agentic coding/chat tools
  that support a "read this file first" or "system instructions" concept can just be
  given the relevant `SKILL.md` as context.
- **Copy the instructions into a prompt** if your tool doesn't support file-based
  instructions at all - the whole point of the format is that it's readable on its own.
- **Tool-specific packaging** (e.g. a `.skill` file for claude.ai, or a plugin manifest
  for a specific agent framework) can be layered on top of these folders without changing
  their content - the folders themselves stay the source of truth.

## License

MIT
